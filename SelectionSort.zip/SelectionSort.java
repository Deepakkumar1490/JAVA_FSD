package AssitedPractice4;

import java.util.Scanner;

public class SelectionSort {

	public static void sort(int[] a)
	{
		 int n = a.length;  
	     int temp = 0;  
	     for(int i=0;i<n;i++){
	    	    for(int j=i+1;j<n;j++){
	    	        if(a[i]>a[j]){
	    	            temp=a[i];
	    	            a[i]=a[j];
	    	            a[j]=temp;
	    	        }
	    	    }    
	    	}
	     System.out.println("After sorting ");
	     for(int k=0;k<a.length;k++)
	     {
	    	 System.out.println(a[k]);
	     }
	}  
		

	public static void main(String[] args)
	{
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of Array");
		n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter Array Elements");
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		sort(a);
		
	}
}
