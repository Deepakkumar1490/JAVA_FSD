package OOPS;

class Ex{

	 private int i;
	 
	 public int getvalue()
	 {
	 return i;
	 }
	 public void setvalue( int i)
	 {
		 System.out.println("Number: " + i);
	 }
	}

public class Encapsulation
	{
	 public static void main(String[] args)
	 {
	 Ex obj = new Ex();
	 obj.setvalue(14);
	 obj.getvalue();
	 }
}

