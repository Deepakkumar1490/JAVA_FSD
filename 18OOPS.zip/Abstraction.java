package OOPS;

abstract class ParentClass
{
  abstract public void show1();
  public void show2()
  {
    System.out.println("Concrete method");
  }
}
class ChildClass extends ParentClass
{
  public void show1()
  {
    System.out.println("abstract method");
  }
  public void show2()
  {
    System.out.println("Overriding concrete method");
  }
}
public class Abstraction
{
  public static void main(String[] args)
  {
    ChildClass obj = new ChildClass();
  obj.show1();
  obj.show2();
  }
}

