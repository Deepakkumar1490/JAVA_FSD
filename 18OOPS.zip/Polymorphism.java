package OOPS;


public class Polymorphism {

	public void display1(String s, int y)
	 {
	 System.out.println(s+" "+y);
	 }
	 public void display2(String a,String b)
	 {
		 System.out.println(a+" "+b);
	 }
	 public void display3(int x, int y,int z)
	 {
		 System.out.println(x+"-"+y+"-"+z);
	 }
	 public static void main(String args[])
	 {
	 Polymorphism a = new Polymorphism();
	 a.display1("Deepak",14);
	 a.display2("Deepak","DOB");
	 a.display3(26,06,2011);
	 }
}
