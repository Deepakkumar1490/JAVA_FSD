package OOPS;

class A{
	void display(int n)
	{
		System.out.println("Number : "+n);
	}
} 

public class ClassObjects {
public static void main(String[] args)
{
	A a=new A();
	a.display(10);
}
}
