package OOPS;

class B
{  
public void sub()
 {
	  System.out.println("Subtraction");
 }  
}

class D extends B{
	public void add()
    {
	System.out.println("Addition");
	}  
}  
class Inheritance{ 
	
public static void main(String args[])
{
	D c=new D();  
    c.add();  
    c.sub();  
}
}  