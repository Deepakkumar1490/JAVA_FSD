package com.springcrud.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.springcrud.beans.employee;

//RowMapper converts Records from ResultSet to Objects

public class EmployeeMapper implements RowMapper<employee>{
	
	    @Override
	    public employee mapRow(ResultSet rs, int rowNum)throws SQLException{
	   
	    	employee emp=new employee();
	    	
	    	emp.setEid(rs.getInt("eid"));
	    	emp.setName(rs.getString("name"));
	    	emp.setDesignation(rs.getString("designation"));
	    	emp.setSalary(rs.getFloat("salary"));
	    	return emp;	
	    }
		
	
}