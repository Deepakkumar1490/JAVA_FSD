package com.springcrud.dao;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import com.springcrud.beans.employee;


@Component
public class EmployeeDao {

	@Autowired
	JdbcTemplate template;
	
	public void setTemplate(JdbcTemplate template){
		this.template=template;
	}
	
	public int insert(employee emp){
		String sql="insert into employee(eid,name,designation,salary)values(?,?,?,?)";
		int ans=template.update(sql,emp.getEid(),emp.getName(),emp.getDesignation(),emp.getSalary());
		return ans;
	}

	public int update(employee emp){
		String sql="update employee set name=?, designation=?, salary=? where eid=?";
		int ans=template.update(sql,emp.getName(),emp.getDesignation(),emp.getSalary(),emp.getEid());
		return ans;
	}
	
	public employee getEmpId(int id){
		String sql="select * from employee where eid=?";
		@SuppressWarnings("deprecation")
		employee emp=template.queryForObject(sql,new Object[]{id},new EmployeeMapper());
		
		
		return emp;
	}
	public List<employee> getEmployeeDetails(){
		String sql="select *from employee";
		List<employee>empList=template.query(sql,new EmployeeMapper());
		return empList;
	}
	
	
}
