package AssitedPractice4;

import java.util.Scanner;

public class InsertionSort {

	    public static  void main(String[] args){

	    	int n;
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter number of Array");
			n=sc.nextInt();
			int a[]=new int[n];
			System.out.println("Enter Array Elements");
			for(int i=0;i<n;i++)
			{
				a[i]=sc.nextInt();
			}
	        insertionSort(a,n);
	        
	     }
	    public static void insertionSort(int[] arr,int n){


	    for(int j=1;j<n;j++){  
	    int key = arr[j];//3
	    int i=j-1;
	    while ((i>-1) && (arr[i]>key)){

	        arr[i+1]=arr[i];
	        i--;
	    }
	    arr[i+1]=key;
	         }
	     System.out.println("After sorting ");
	     for(int k=0;k<n;k++)
	     {
	    	 System.out.println(arr[k]);
	     

	    }
	}
}
