package Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import classess.class1;
import classess.student;
import classess.subject;
import classess.teacher;


/**
 * Servlet implementation class AddServlet
 */
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@SuppressWarnings("unchecked")
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String classname=request.getParameter("cname");
		String subject1=request.getParameter("sub1name");
		String subject2=request.getParameter("sub2name");
		String subject3=request.getParameter("sub3name");
		String teacher1=request.getParameter("t1name");
		String teacher2=request.getParameter("t2name");
		String teacher3=request.getParameter("t3name");
        String student1=request.getParameter("stu1name");
		String student2=request.getParameter("stu2name");
		String student3=request.getParameter("stu3name");
		String student4=request.getParameter("stu4name");
	
      
		class1 c1=new class1();
		c1.setClassname(classname);
		
		subject s1=new subject();
		s1.setSubjectname(subject1);
		subject s2=new subject();
		s2.setSubjectname(subject2);
		subject s3=new subject();
		s3.setSubjectname(subject3);
		
		teacher t1=new teacher();
		t1.setTeachername(teacher1);
		teacher t2=new teacher();
		t2.setTeachername(teacher2);
		teacher t3=new teacher();
		t3.setTeachername(teacher3);
		
		student stud1=new student();
		stud1.setStudentname(student1);
		student stud2=new student();
		stud2.setStudentname(student2);
		student stud3=new student();
		stud3.setStudentname(student3);
		student stud4=new student();
		stud4.setStudentname(student4);
		
	    c1.getSubjects().add(s1);
	    c1.getSubjects().add(s2);
	    c1.getSubjects().add(s3);
	    
	    s1.getClasses().add(c1);
	    s2.getClasses().add(c1);
	    s3.getClasses().add(c1);
	    
	    c1.getTeachers().add(t1);
	    c1.getTeachers().add(t2);
	    c1.getTeachers().add(t3);
	    
	    t1.getClasses().add(c1);
	    t2.getClasses().add(c1);
	    t3.getClasses().add(c1);
	    
	    c1.getStudents().add(stud1);
	    c1.getStudents().add(stud2);
	    c1.getStudents().add(stud3);
	    c1.getStudents().add(stud4);
	    
	    t1.getSubjects().add(s1);
	    t2.getSubjects().add(s2);
	    t3.getSubjects().add(s3);
	    
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		
		int i=(Integer)session.save(c1);
		session.getTransaction().commit();	
		session.close();
		PrintWriter out = response.getWriter();
		if (i > 0)
			out.println("Record inserted");
		else
			out.println("Record not inserted");
		
	}

}
