package classess;

import java.util.*;
import javax.persistence.*;

@Entity
@Table
public class class1 {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cls_gen")
	@SequenceGenerator(name="cls_gen", sequenceName = "cls_seq")
	private int classid;
	
	@Column(length=20)
	private String classname;
	
	@OneToMany(targetEntity=student.class , cascade=CascadeType.ALL)
	@JoinTable(name="Class_Student", joinColumns= {@JoinColumn(name="classid")}, inverseJoinColumns= {@JoinColumn(name="studentid")})
	Set<student> students=new HashSet<student>();

	@ManyToMany(targetEntity = subject.class , cascade=CascadeType.ALL)
	@JoinTable(name="Class_Subject", joinColumns= {@JoinColumn(name="classid")}, inverseJoinColumns= {@JoinColumn(name="subjectid")})
	Set<subject> subjects=new HashSet<subject>();
	
	@ManyToMany(targetEntity = teacher.class , cascade=CascadeType.ALL)
	@JoinTable(name="Class_Teacher", joinColumns= {@JoinColumn(name="classid")}, inverseJoinColumns= {@JoinColumn(name="teacherid")})
	Set<teacher> teachers=new HashSet<teacher>();

	public int getClassid() {
		return classid;
	}

	public void setClassid(int classid) {
		this.classid = classid;
	}

	public String getClassname() {
		return classname;
	}

	public void setClassname(String classname) {
		this.classname = classname;
	}

	public Set<student> getStudents() {
		return students;
	}

	public void setStudents(Set<student> students) {
		this.students = students;
	}

	public Set<subject> getSubjects() {
		return subjects;
	}

	public void setSubjects(Set<subject> subjects) {
		this.subjects = subjects;
	}

	public Set<teacher> getTeachers() {
		return teachers;
	}

	public void setTeachers(Set<teacher> teachers) {
		this.teachers = teachers;
	}
	
		
	}
