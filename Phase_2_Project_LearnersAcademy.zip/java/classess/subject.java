package classess;

import java.util.*;
import javax.persistence.*;

@Entity
@Table
public class subject {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sub_gen")
	@SequenceGenerator(name="sub_gen", sequenceName = "sub_seq")
	private int subjectid;
	
	@Column(length=20)
	private String subjectname;
	
	@ManyToMany(mappedBy="subjects")
	Set<class1> classes=new HashSet<class1>();

	public int getSubjectid() {
		return subjectid;
	}

	public void setSubjectid(int subjectid) {
		this.subjectid = subjectid;
	}

	public String getSubjectname() {
		return subjectname;
	}

	public void setSubjectname(String subjectname) {
		this.subjectname = subjectname;
	}

	public Set<class1> getClasses() {
		return classes;
	}

	public void setClasses(Set<class1> classes) {
		this.classes = classes;
	}
	
	
}
