package classess;

import java.util.*;
import javax.persistence.*;

@Entity
@Table
public class teacher {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "teach_gen")
	@SequenceGenerator(name="teach_gen", sequenceName = "teach_seq")
	private int teacherid;

	@Column(length=20)
	private String teachername;

	@ManyToMany(mappedBy="teachers")
	Set<class1> classes=new HashSet<class1>();
	
	@OneToMany(targetEntity=subject.class , cascade=CascadeType.ALL)
	@JoinTable(name="Teacher_Subject", joinColumns= {@JoinColumn(name="teacherid")}, inverseJoinColumns= {@JoinColumn(name="subjectid")})
	Set<subject> subjects=new HashSet<subject>();
	
	public int getTeacherid() {
		return teacherid;
	}

	public void setTeacherid(int teacherid) {
		this.teacherid = teacherid;
	}

	public String getTeachername() {
		return teachername;
	}

	public void setTeachername(String teachername) {
		this.teachername = teachername;
	}

	public Set<class1> getClasses() {
		return classes;
	}

	public void setClasses(Set<class1> classes) {
		this.classes = classes;
	}

	public Set<subject> getSubjects() {
		return subjects;
	}

	public void setSubjects(Set<subject> subjects) {
		this.subjects = subjects;
	}

	
}
