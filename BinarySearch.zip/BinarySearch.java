package AssitedPractice4;

import java.util.Scanner;

public class BinarySearch {


	public static boolean binarySearching(int arr[],int key){
		boolean ans=false;
		int st=0;
		int end=arr.length-1;
		int mid;
		while(st<=end){
			mid=(st+end)/2;
			if(arr[mid]==key){
				ans=true; break;
			}
			else
				if(arr[mid]<key)
					st=mid+1;
				else
					end=mid-1;
				
		}
		
	return ans;
	}
	
	public static void main(String[] args) {
		
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of Array");
		n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter Array Elements");
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}

		SelectionSort.sort(a);
		
		System.out.println("\nEnter a value to be searched");
		int key=sc.nextInt();
		
		boolean ans=binarySearching(a,key);
		if(ans)
			System.out.println("Value present");
		else
			System.out.println("Value not present");

	}
	

}
