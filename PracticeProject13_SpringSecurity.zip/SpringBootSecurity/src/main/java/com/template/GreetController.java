package com.template;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetController {
	
	@GetMapping("/deepak")
	public String getMessage() {
		return "<h1> Welcome Deepak</h1>";
	}

	@GetMapping("/kumar")
	public String getMsg() {
		return "<h1> Welcome Kumar</h1>";
	}
}