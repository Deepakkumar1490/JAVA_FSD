package typecast;

public class typecast1 {

	public static void main(String[] args) {
		
		int i=14;
		double h2=(double) i;
		
		char ch='h';
		int j=(int) ch;
		
		float k=2.56f;
		double l=(double) k;
		
		double m = 45.678d;
	    int n = (int) m;
	    
		System.out.println("Integer value "+i);
		System.out.println("Integer to Long "+h2);
		
		System.out.println("\nCharacter Value "+ch);
		System.out.println("Character to Integer "+j);
		
		System.out.println("\nFloat Value "+k);
		System.out.println("Float to Double "+l);
		
		System.out.println("\nDouble Value "+m);
		System.out.println("Double to Integer "+n);

		

	}

}
