package ExceptionHandling;

public class trycatch {

	public static void main(String[] args) {
		
		try{
			System.out.println("Divide by 7/0");
			System.out.println(7/0);
		}
		
		catch(ArithmeticException|ArrayIndexOutOfBoundsException e){
			System.out.println("divisble by 0 not possible");
		}
		
	}
}
