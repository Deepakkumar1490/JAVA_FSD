package FixBugs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class fix_bugs {

	
    public static void main(String[] args) {
    	
        System.out.println("Welcome");
        optionsSelection();

    }
    private static void optionsSelection() {
        String[] s = {"1. I wish to review my expenditure","2. I wish to add my expenditure","3. I wish to delete my expenditure",
                "4. I wish to sort the expenditures","5. I wish to search for a particular expenditure","6. Close the application"};
       int[] a = {1,2,3,4,5,6};
        int  len = s.length;
        for(int i=0; i<len;i++){
            System.out.println(s[i]);

        }
    
       ArrayList<Integer> arrlist = new ArrayList<Integer>();
        ArrayList<Integer> exp = new ArrayList<Integer>();
        exp.add(5000);
        exp.add(6700);
        exp.add(25000);
        exp.add(19000);
        exp.add(900);
       
        System.out.println("\nEnter your choice:\t");
        Scanner sc = new Scanner(System.in);
        int  options =  sc.nextInt();
                switch (options){
                    case 1:
                    { 
                    	System.out.println("Your saved expenses are listed below: \n");
                        System.out.println(exp+"\n");
                        optionsSelection();
                        break;
                    }
                    case 2:
                    { System.out.println("Enter the value to add your Expense: \n");
                        int value = sc.nextInt();
                        exp.add(value);
                        
                        System.out.println(exp+"\n");
                        optionsSelection();
                        break;
                        
                    }
                    case 3:
                    {
                    	System.out.println("You are about the delete all your expenses! \nConfirm again by selecting the same option...\n");
                        int con_choice = sc.nextInt();
                        if(con_choice==options){
                               exp.clear();
                            System.out.println(exp+"\n");
                            System.out.println("All your expenses are erased!\n");
                        } else {
                            System.out.println("Oops... try again!");
                        }
                        optionsSelection();
                        break;
                    }
                    case 4:
                        sortExpenses(exp);
                        optionsSelection();
                        break;
                    case 5:
                     searchExpenses(exp);
                        optionsSelection();
                        break;
                    
                    case 6:
                        closeApp();
                        break;
                    default:
                        System.out.println("You have made an invalid choice!");
                        break;
                }
            }


    
    private static void closeApp() {
        System.out.println("Closing your application");
            }
    private static void searchExpenses(ArrayList<Integer> arrayList) {
        int l = arrayList.size();
        System.out.println("Enter the expense you need to search:\t");
        Scanner sc=new Scanner(System.in);
        int exp=sc.nextInt();
        	if(arrayList.contains(exp))
        	{
        		System.out.println("Expenditure Found in the list ");
        	}
        	else{
        		System.out.println("Expenditure Not Found");
        	}
        
        System.out.println();
        
    }
    private static void sortExpenses(ArrayList<Integer> arrayList) {
        int arrlength =  arrayList.size();
        Collections.sort(arrayList);
        System.out.println("\nAfter Sorting the expenditures in ascending order: "+arrayList);
        System.out.println();

    }
}