package Project;

import org.testng.annotations.Test;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Phase_5_Project {
	
	WebDriver driver;
	
    @Test
    public void f() throws InterruptedException {
    	
    	System.setProperty("webdriver.chrome.driver","F:\\SELENIUM\\chromedriver_win32(106Version)/chromedriver.exe");
		driver = new ChromeDriver();
		//capture time before page load
	    long s = System.currentTimeMillis();
	    //Opening Browser
	    driver.get("https://www.flipkart.com/");
	    long e = System.currentTimeMillis();
	    //compute time
	    long r = e-s;
	    System.out.println("Page load time in milliseconds: "+ r);
	    
	    WebElement search=driver.findElement(By.xpath("//*[@name='q']"));
	    search.clear();
	    search.sendKeys("iphone 13");
	    search.click();
	    
	    driver.findElement(By.xpath("//button[@class='L0Z3Pu']")).click();
	    Thread.sleep(4000);
	    
	    driver.findElement(By.xpath("//*[@class='_4rR01T']")).click();
	    Thread.sleep(4000);
	    
	    String execScript = "return document.documentElement.scrollHeight>document.documentElement.clientHeight;";
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Boolean test = (Boolean) (js.executeScript(execScript));
		if (test == true) {
			System.out.print("Scrollbar is present.");
		} else if (test == false){
			System.out.print("Scrollbar is not present.");
		}
		
        Set<String> Handles = driver.getWindowHandles();
	    for(String actual: Handles)
	    {
	    	driver.switchTo().window(actual);
	    }
		driver.navigate().refresh();
		
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
	    Thread.sleep(2000);
	    System.out.println("===========================");
	    System.out.println("Wait Check");
	    
	    js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
    }
}
