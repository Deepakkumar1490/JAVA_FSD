package com.DI;

public class SpellChecker {

	public SpellChecker() {
		System.out.println("Constructor invoke");
	}
	public void method() {
		System.out.println("Method Invoke");
	}
}
