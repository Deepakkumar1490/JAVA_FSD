package com.testing;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import com.service.MessageService;

@SpringBootTest
class SpringBootJuNitApplicationTests {

	@Autowired
	private MessageService ms;

	@Test
	@DisplayName("Login Test")
	void loginMessage() {
		
		String username="Deepak";
		String password="Deepak@123";

		String message=ms.message(username,password);
		assertEquals("Successfully Login",message);
	}

}
