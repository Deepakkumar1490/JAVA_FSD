package com.service;

import org.springframework.stereotype.Component;

@Component
public class MessageService {
	
	public String message(String username,String password) {
		return "Successfully Login";
	}
}