package DynamicTests;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;
import java.util.Collection;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;

class DynamicTest1 {

	/* Dynamic testing means test case generate at runtime
	@TestFactory-- using for DynamicTest. it always return stream, collection, iterator, Junitexception
	it should  be used with static or privae methods
	@BeforeEach,@AfterEach will not call with DynamicTest*/


	@TestFactory
	Collection<DynamicTest> dynamictest1(){
		return Arrays.asList(
				DynamicTest.dynamicTest("Add Test",()-> assertEquals(4,Math.addExact(1, 3))),
				DynamicTest.dynamicTest("Multiply Test",()-> assertEquals(8,Math.multiplyExact(4, 2)))
				);
	}
 }

