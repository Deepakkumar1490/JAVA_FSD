package MATHS;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MathsTest {

	@Test
	void add() {
		assertEquals(6,Maths.add(3,3));
	}
	
	@Test
	  void test_Multiply() {
	    assertEquals(15, Maths.mul(3, 5));
	  }
	
	  @Test
	  void test_isEven() {
	    assertTrue(Maths.isEven(12));
	  }

	  @Test
	  void test_Divide() {
	    assertEquals(5, Maths.divide(25, 5));
	  }
	  
	  @Test
	  void testIs_Prime() {
	    assertTrue(Maths.isPrime(13));
	  }

}
