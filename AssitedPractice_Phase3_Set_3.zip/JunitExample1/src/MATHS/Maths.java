package MATHS;

public class Maths {

	public static int add(int n1,int n2)
	{
		return n1+n2;
	}
	
	public static int mul(int n1,int n2)
	{
		return n1*n2;
	}
	
	public static boolean isEven(int n1)
	{
		return n1%2 == 0;
	}
	
	public static int divide(int n1,int n2)
	{
		return n1/n2;
	}
	
	public static boolean isPrime(int num)
	{
		for(int i=2;2*i<num;i++)
		{
			if(num%i==0)
				return false;
		}
		return true;
	}
}
