package DependencyInjectionTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(FooParameterResolver.class)
public class DependencyInjection2 {
	
	    @Test   
	    @Tag("my-tag")
	   
	    void validate(Calculation c) {
	        assertTrue(c.user1("Deepak"));	
	        assertTrue(c.pass1("Deepak@123"));
	    }

}