package DependencyInjectionTest;

public class Calculation {

	public static boolean user1(String user) {
		String username="Deepak";
		if(username==user)
			return true;
		return false;
	}
	public static boolean pass1(String pass) {
		String password="Deepak@123";
		if(password==pass)
			return true;
		return false;
	}
}
