package NestedTests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

@DisplayName("Nested Test")
class NestedTest1 {

	@Test
	void Test1() {
		System.out.println("Test 1");	
	}
	
	@Nested
	@DisplayName("Test A")
	class TestA{
	
		@Test
		void TestA1() {
			System.out.println("Test A1");	
		}
		
		@Nested
		@DisplayName("Test A2")
		class TestAA{
			
			@Test
			void TestA2() {
				System.out.println("Test A2");	
			}

		}
	}
	
	@Nested
	  @DisplayName("Nested Test B")
	  class TestB {

	    @Test
	    void testB_test1() {
	      System.out.println("Test B");
	    }
	  }


}
