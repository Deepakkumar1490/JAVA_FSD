package pkg2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculationTest {

	@Test
	void Test() {
		Calculation cal=new Calculation();
		assertEquals(13,cal.addition(7, 6));
	}
}
