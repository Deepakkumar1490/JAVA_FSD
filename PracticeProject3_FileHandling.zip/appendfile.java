package FileHandling;
import java.io.BufferedWriter;
import java.io.FileWriter; 
import java.io.IOException; 
import java.io.PrintWriter; 
public class appendfile{ 
	public static void main(String args[]) throws IOException { 
		FileWriter a = null; 
		BufferedWriter b = null; 
		PrintWriter c = null; 
		try { 
			a = new FileWriter("C:\\Users\\deepak\\eclipse-workspace\\Practice_Project\\src\\FileHandling\\new1.txt", true); 
			b = new BufferedWriter(a); 
			c = new PrintWriter(b); 
			c.println("Deepak");
			c.println("Kumar"); 
			c.println("R"); 
			System.out.println("Data Successfully appended into file"); 
			c.flush(); 
			} 
		finally { 
			try { 
				c.close(); 
				b.close(); 
				a.close(); 
				} 
			catch (IOException io) {
			}
			}
				try (FileWriter f = new FileWriter("C:\\\\Users\\\\deepak\\\\eclipse-workspace\\\\Practice_Project\\\\src\\\\FileHandling\\\\new1.txt", true); 
						BufferedWriter d = new BufferedWriter(f); 
						PrintWriter p = new PrintWriter(d);) { 
					p.println(" appending text into file "); 
					p.println("14 "); 
					p.println("9 "); 
					} 
				catch (IOException i) { 
						i.printStackTrace(); 
						} 
				} 
			}
		
		
	

