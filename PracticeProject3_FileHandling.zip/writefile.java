package FileHandling;
import java.io.FileWriter; 
import java.io.IOException; 
public class writefile {
  public static void main(String[] args) {
    try {
      FileWriter myWriter = new FileWriter("C:\\Users\\deepak\\eclipse-workspace\\Practice_Project\\src\\FileHandling\\new1.txt");
      myWriter.write("Welcome to file\n");
      myWriter.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
  }
}