package com.to;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFileUploadDownloadApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringFileUploadDownloadApplication.class, args);
	}

}
