package com.template;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLocalHostExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
