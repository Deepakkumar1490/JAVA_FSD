package LongestIncreasingSubsequence;
import java.util.Scanner;

public class Sequence {

		static int a; 
		static int val1(int arr[], int n)
		{
			if (n == 1)
				return 1;
			
			int c, b = 1;
			
			for (int i = 1; i < n; i++) {
				c =val1(arr, i);
				if (arr[i - 1] < arr[n - 1] && c + 1 > b)
					b = c + 1;
			}
			
			if (a< b)
				a = b;
			
			return b;
		}
		
		static int val(int arr[], int n)
		{
			
			a = 1;

			val1(arr, n);
			
			return a;
		}
		
		public static void main(String args[])
		{
			int n;
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter length of array");
			n=sc.nextInt();
			int arr[] = new int[n];
			System.out.println("Enter Array Elements");
			for(int i=0;i<n;i++)
			{
				arr[i]=sc.nextInt();
			}
			System.out.println("Longest Increasing Subsequence is "+ val(arr, n));
		}
	}

