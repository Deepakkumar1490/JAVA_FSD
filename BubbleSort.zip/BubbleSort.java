package AssitedPractice4;

import java.util.Scanner;

public class BubbleSort {

	public static void sort(int[] a)
	{
		 int n = a.length;  
	     int temp = 0;  
	     for(int i=0; i < n; i++)
	     {  
	      for(int j=1; j < (n-i); j++)
	      {  
	       if(a[j-1] > a[j])
	       {                             
	          temp = a[j-1];  
	          a[j-1] = a[j];  
	          a[j] = temp;  
	       }                 
	      }  
    	}
	     System.out.println("After sorting ");
	     for(int k=0;k<a.length;k++)
	     {
	    	 System.out.println(a[k]);
	     }
		
	}
	public static void main(String[] args)
	{
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of Array");
		n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter Array Elements");
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		sort(a);
		
	}
}
