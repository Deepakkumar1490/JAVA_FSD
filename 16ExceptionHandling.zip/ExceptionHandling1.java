package ExceptionHandling;
import java.util.Scanner;

class WithdrawException extends Exception{
	static double balance;
	//double Wbal;
	public WithdrawException(String msg)
	{
		super(msg);
	}
	static void withdraw(double bal)
	{
		try {
			balance=25000.0;
			
		if(bal>balance) {
			System.out.println("remaining bal: "+(bal));
		}
		else {
			throw new WithdrawException("Insufficient balance");
		}
			
	}catch(WithdrawException e)
		{
		e.printStackTrace();
		}		
	}
}
public class ExceptionHandling1 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter amount need to withdraw");
		double amnt= sc.nextDouble();
		WithdrawException.withdraw(amnt);

   }
 }