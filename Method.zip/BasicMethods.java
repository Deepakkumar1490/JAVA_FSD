package Methods;
import java.util.Scanner;

public class BasicMethods {

	public int multiple(int x, int y)
	{
		return x*y;
	}
 
	public int addition(int x,int y,int z)
	{
		return x+y+z;
	}
	public static void main(String[] args) {
		
		int a,b,c;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a,b,c value");
		a=sc.nextInt();
		b=sc.nextInt();
		c=sc.nextInt();
		BasicMethods h=new BasicMethods();
		int mul=h.multiple(a, b);
		int add=h.addition(a,b,c);
		System.out.println("\nMultiple of A and B"+" : "+mul);
		System.out.println("Addition of A,B and C"+" : "+add);

	}
}
