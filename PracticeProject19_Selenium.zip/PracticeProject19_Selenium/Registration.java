package com.example;
import org.openqa.selenium.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.support.ui.Select;

public class Registration {

	public static void main(String[] args) throws InterruptedException{
		System.setProperty("webdriver.chrome.driver", "F:\\SELENIUM\\chromedriver_win32(106Version)/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[@class='_42ft _4jy0 _6lti _4jy6 _4jy2 selected _51sy']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@placeholder='First name']")).sendKeys("Deepak Kumar");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("R");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@name='reg_email__']")).sendKeys("deepak@gmail.com");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@name='reg_email_confirmation__']")).sendKeys("deepak@gmail.com");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@name='reg_passwd__']")).sendKeys("123456789");
		Thread.sleep(2000);
		
		Select dob1 = new Select(driver.findElement(By.cssSelector("#reg > div > div:nth-child(5) > div:nth-child(2) > span:nth-child(1) >span >select")));
		dob1.selectByVisibleText("14");
		Thread.sleep(2000);
		
		
		WebElement month=driver.findElement(By.name("birthday_month"));
	    Select select= new Select(month);
	    select.selectByVisibleText("Sep");
	    Thread.sleep(2000);
	    
	    WebElement year =driver.findElement(By.name("birthday_year"));
	    Select select1 = new Select(year);
	    select1.selectByVisibleText("2000");
	    Thread.sleep(2000);
		
		WebElement gender=driver.findElement(By.cssSelector("#reg > div > div:nth-child(7) >span>span:nth-child(2)>input"));
		gender.click();
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("//button[@class='_6j mvm _6wk _6wl _58mi _3ma _6o _6v']")).click();
		Thread.sleep(4000);
		
	}

}
