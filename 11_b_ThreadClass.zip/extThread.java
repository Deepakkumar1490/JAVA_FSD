package MultiThreading;

class Thread1 extends Thread{
	public void run()
	{
		System.out.println("End");
	}
}
public class extThread {

	public static void main(String[] args)
	{
		Thread1 t= new Thread1();
		
		t.setName("Thread1");
		t.setPriority(8);
		System.out.println("ExtRunnable class Thread :"+t);
		t.start();
		
		System.out.println(" class");
		
	}
}