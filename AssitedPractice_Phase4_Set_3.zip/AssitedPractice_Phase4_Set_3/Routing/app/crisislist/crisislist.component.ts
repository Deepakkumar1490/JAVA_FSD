import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crisislist',
  templateUrl: './crisislist.component.html',
  styleUrls: ['./crisislist.component.css']
})
export class CrisislistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
