import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HeroeslistComponent } from './heroeslist/heroeslist.component';
import { CrisislistComponent } from './crisislist/crisislist.component';
import { RouterModule } from '@angular/router';
@NgModule({
  declarations: [
    AppComponent,
    HeroeslistComponent,
    CrisislistComponent
  ],
  imports: [
    BrowserModule,FormsModule,

    RouterModule.forRoot([
      {path:'crisislist' ,component:CrisislistComponent},
      {path:'heroeslist',component:HeroeslistComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
