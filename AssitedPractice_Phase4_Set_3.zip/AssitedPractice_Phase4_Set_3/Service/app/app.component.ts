import { Component } from '@angular/core';
import { ServicenameService } from './servicename.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ServiceExample';
  
  value:string="";
  productList:Array<any>=[];

  constructor(private s:ServicenameService){}

  ngOnInit():void{
    this.value=this.s.getvalue();
    this.productList=this.s.getArray();
  }
}
