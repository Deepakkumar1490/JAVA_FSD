import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServicenameService {

  constructor() { }
  
  getvalue():string{
    return "Hello";
  }

  getArray():Array<any>{
    return [{name:"orange",price:200},
            { name:"apple",price:150}];
  }
}
