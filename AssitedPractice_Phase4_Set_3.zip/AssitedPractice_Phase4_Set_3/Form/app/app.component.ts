import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Login';

 product:Array<any>=[{name:"Pen",price:20,item:50},
                     {name:"Rubber",price:5,item:100},
                     {name:"Notebook",price:40,item:20}   ];
  
  public clickCount:number=0;
  onCountChanged(count:number):void{
    this.clickCount=count;
  }
}
