import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-shopping',
  templateUrl: './shopping.component.html',
  styleUrls: ['./shopping.component.css']
})
export class ShoppingComponent implements OnInit {

  @Input() productList:Array<any>=[];
  constructor() { }
  
  ngOnInit(): void {
  }

  public clickCount:number=0;
  @Output() onChanged=new EventEmitter<number>();

  countChange(count : number):void{
    count++;
    this.clickCount=count;
    this.onChanged.emit(this.clickCount);
  }
  
}
