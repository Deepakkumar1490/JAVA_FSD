import { Directive ,ElementRef,Renderer2,HostListener} from '@angular/core';

@Directive({
  selector: '[appColorChange]'
})
export class ColorChangeDirective {

  constructor(private ele:ElementRef,private render:Renderer2) {
         ele.nativeElement.style.backgroundColor='yellow';
       //render.setStyle(ele.nativeElement,'backgroundColor','red');
   }

   setBgColor(color:string){
    this.render.setStyle(this.ele.nativeElement,'backgroundColor',color);
   }
   @HostListener('mouseenter') onMouseEnter(){
       this.setBgColor('pink');
   }
   @HostListener('mouseleave') onMouseLeave(){
    this.setBgColor('green');
   }
  }
