import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username:string="";
  userpassword:string="";
  msg:string="";
  status:string="";
  imgpath:string="./assets/A1.png";

  product:Array<any>= [ {name:"Apple",price:200} , {name:"Orange",price:150} ];
  show:boolean=true;
  constructor() { }

  ngOnInit(): void {
  }
  
  validation():void {
    if((this.username=="user1")&&(this.userpassword=="hello")){
      this.status="valid";
      this.msg="Welcome "+this.username;
    }
    else{
      this.status="error";
      this.msg="Invalid";
    }
  }
}
