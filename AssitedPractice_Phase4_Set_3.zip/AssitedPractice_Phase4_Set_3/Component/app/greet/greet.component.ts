import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-greet',
  templateUrl: './greet.component.html',
  styleUrls: ['./greet.component.css']
})
export class GreetComponent implements OnInit {

  name:string="kumar";

  constructor() { }

  ngOnInit(): void {
  }
  
  greet():void{
    alert("Name is :"+this.name);
  }
}
