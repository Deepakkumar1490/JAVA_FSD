package MultiThreading;

class MyNewThread implements Runnable{

	
	public void run() {
		System.out.println("I am new Thread");
		
	}
	
}
public class impRunnable {

	public static void main(String[] args) {
		
		System.out.println("Main Method start");
		Thread t=new Thread(new MyNewThread());
		t.setName("Thread1");
		t.setPriority(8);
		System.out.println("ExtRunnable class Thread :"+t);
		
		t.start();
		
		System.out.println("Main Method Stop");
		
	}

}