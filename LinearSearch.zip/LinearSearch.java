package AssitedPractice4;

import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args)
	{
		int a[]= {12,4,35,14,65,23,25};
		Scanner sc=new Scanner(System.in);
		int key,flag=0;
		System.out.println("Enter Search element");
		key=sc.nextInt();
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==key)
			{
				System.out.println("Key found");
				flag=1;
			}
		}
		if(flag==0)
		{
			System.out.println("Key not found");
		}
    
}
}