package com.springproject.SpringBootOnlineQuiz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootOnlineQuizApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootOnlineQuizApplication.class, args);
	}

}
